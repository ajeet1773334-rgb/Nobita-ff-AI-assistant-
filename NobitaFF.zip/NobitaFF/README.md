# Nobita FF – Voice Assistant (Android)

Hindi/English awaaz se phone control karne wala assistant.

## APK kaise banaye (free, GitHub se)
1. github.com par free account banao.
2. "New repository" banao (Public ya Private).
3. Is folder ki saari files upload karo (ya sirf `setup_project.py` + `.github/workflows/build.yml`).
4. "Actions" tab -> "Build APK" -> "Run workflow".
5. 3-5 minute baad run ke andar "Artifacts" me `NobitaFF-APK` download karo, zip kholo, `app-debug.apk` install karo.

## Pehli baar setup
- Mic, Contacts, Phone ki permission do.
- Phone Settings -> Accessibility -> "Nobita FF Assistant" ON karo (lock + WhatsApp send ke liye).
