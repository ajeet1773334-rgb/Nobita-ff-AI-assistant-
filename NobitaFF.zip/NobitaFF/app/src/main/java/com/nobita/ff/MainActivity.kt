package com.nobita.ff

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var continuous = false
    private var inForeground = false
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var processor: CommandProcessor

    private val logLines = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        processor = CommandProcessor(this) { speak(it) }
        tts = TextToSpeech(this, this)
        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE
            ),
            1
        )
    }

    override fun onResume() {
        super.onResume()
        inForeground = true
        refreshStatus()
        if (continuous) handler.postDelayed({ startListening() }, 600)
    }

    override fun onPause() {
        super.onPause()
        inForeground = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel()
        listening = false
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
    }

    // ---------- awaaz bolna (TTS) ----------

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            addLog("(आवाज़ वाला इंजन चालू नहीं हो पाया)")
            return
        }
        val r = tts.setLanguage(Locale("hi", "IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale.US)
            addLog("(हिंदी आवाज़ नहीं मिली। Google Text-to-speech में हिंदी वॉइस डाउनलोड कर लीजिए)")
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                runOnUiThread { afterSpeech() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                runOnUiThread { afterSpeech() }
            }
        })
        ttsReady = true
        speak("नमस्ते, मैं नोबिता हूँ। बोलिए, मैं क्या करूँ?")
    }

    private fun speak(text: String) {
        runOnUiThread {
            addLog("नोबिता: $text")
            if (ttsReady) {
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nobita")
            } else {
                afterSpeech()
            }
        }
    }

    private fun afterSpeech() {
        if (continuous && inForeground) {
            handler.postDelayed({ startListening() }, 300)
        }
    }

    // ---------- sunna (Speech-to-text) ----------

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            setStatus("सुन रहा हूँ…")
        }

        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            setStatus("समझ रहा हूँ…")
        }

        override fun onError(error: Int) {
            listening = false
            refreshStatus()
            val retry = error == SpeechRecognizer.ERROR_NO_MATCH ||
                error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY
            if (continuous && inForeground && retry) {
                handler.postDelayed({ startListening() }, 600)
            } else if (error != SpeechRecognizer.ERROR_CLIENT) {
                addLog("(सुनने में दिक्कत, कोड $error)")
            }
        }

        override fun onResults(results: Bundle?) {
            listening = false
            refreshStatus()
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) {
                afterSpeech()
                return
            }
            addLog("आप: $text")
            onHeard(text)
        }

        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun onHeard(text: String) {
        val low = text.lowercase(Locale.ROOT)
        if (low.contains("stop listening") || low.contains("सुनना बंद") || low.contains("sunna band") ||
            low.contains("अलविदा") || low.contains("bye")
        ) {
            continuous = false
            findViewById<Switch>(SWITCH_ID)?.isChecked = false
            speak("ठीक है, अब मैं नहीं सुन रहा। फिर मिलेंगे।")
            return
        }
        processor.handle(text)
    }

    private fun startListening() {
        if (listening) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            Toast.makeText(this, "माइक की अनुमति दीजिए", Toast.LENGTH_SHORT).show()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addLog("(इस फ़ोन में Google की वॉइस सर्विस नहीं मिली)")
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(listener)
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        listening = true
        recognizer?.startListening(i)
    }

    // ---------- screen ----------

    private val SWITCH_ID = 7001

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundBg(color: String, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.parseColor(color))
        }

    private fun smallButton(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = roundBg("#21262D", 12)
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                marginStart = dp(4)
                marginEnd = dp(4)
            }
        }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0D1117"))
            setPadding(dp(20), dp(36), dp(20), dp(16))
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "NOBITA FF"
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#FFC107"))
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val sub = TextView(this).apply {
            text = "आपका वॉइस असिस्टेंट"
            textSize = 14f
            setTextColor(Color.parseColor("#8B949E"))
            gravity = Gravity.CENTER
        }
        root.addView(sub, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        statusView = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#58A6FF"))
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
        }
        root.addView(statusView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val mic = Button(this).apply {
            text = "🎤  बोलिए"
            textSize = 20f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#0D1117"))
            background = roundBg("#FFC107", 20)
            setOnClickListener { startListening() }
        }
        root.addView(mic, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(72)))

        val sw = Switch(this).apply {
            id = SWITCH_ID
            text = "लगातार सुनो (ऐप खुला रहे)"
            setTextColor(Color.WHITE)
            setPadding(0, dp(14), 0, dp(14))
            setOnCheckedChangeListener { _, checked ->
                continuous = checked
                if (checked) startListening() else recognizer?.cancel()
                if (!checked) listening = false
            }
        }
        root.addView(sw, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        scroll = ScrollView(this).apply {
            background = roundBg("#161B22", 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        logView = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.parseColor("#E6EDF3"))
            setLineSpacing(0f, 1.15f)
        }
        scroll.addView(logView)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, 0)
        }
        row.addView(smallButton("Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        row.addView(smallButton("API Key") { showApiKeyDialog() })
        row.addView(smallButton("Commands") { showCommands() })
        root.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(root)
        refreshStatus()
    }

    private fun setStatus(s: String) {
        runOnUiThread { statusView.text = s }
    }

    private fun refreshStatus() {
        val acc = if (NobitaService.instance != null) "Accessibility: चालू ✅" else "Accessibility: बंद ❌ (लॉक और WhatsApp के लिए चालू करें)"
        val mode = if (listening) "सुन रहा हूँ…" else "तैयार"
        setStatus("$mode\n$acc")
    }

    private fun addLog(line: String) {
        runOnUiThread {
            logLines.add(line)
            while (logLines.size > 40) logLines.removeAt(0)
            logView.text = logLines.joinToString("\n\n")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun showApiKeyDialog() {
        val prefs = getSharedPreferences("nobita", Context.MODE_PRIVATE)
        val input = EditText(this).apply {
            hint = "sk-ant-..."
            setText(prefs.getString("api_key", ""))
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Claude API Key (ज़रूरी नहीं)")
            .setMessage("यह सिर्फ़ तब चाहिए जब आप Nobita से हर तरह के सवाल पूछना चाहें। बाकी सारे कमांड बिना Key के चलते हैं। Key आपके फ़ोन में ही रहती है।")
            .setView(input)
            .setPositiveButton("सेव") { _, _ ->
                prefs.edit().putString("api_key", input.text.toString().trim()).apply()
                Toast.makeText(this, "सेव हो गया", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("रद्द", null)
            .show()
    }

    private fun showCommands() {
        val msg = "• फ़ोन लॉक करो\n" +
            "• राहुल को व्हाट्सएप पर हेलो भेजो\n" +
            "• मम्मी को कॉल करो\n" +
            "• यूट्यूब खोलो / फ्री फायर खोलो\n" +
            "• सुबह 7 बजे का अलार्म लगाओ\n" +
            "• 5 मिनट का टाइमर लगाओ\n" +
            "• टॉर्च चालू करो / बंद करो\n" +
            "• वॉल्यूम बढ़ाओ / कम करो / म्यूट\n" +
            "• स्क्रीनशॉट लो, होम, पीछे जाओ\n" +
            "• वाईफाई / ब्लूटूथ (सेटिंग खुलती है)\n" +
            "• कितने बजे हैं / आज की तारीख\n" +
            "• यूट्यूब पर अरिजीत के गाने बजाओ\n" +
            "• गूगल पर ... सर्च करो\n" +
            "• ... का रास्ता दिखाओ\n" +
            "• बाकी कुछ भी पूछो (Claude API Key चाहिए)\n\n" +
            "रोकने के लिए: \"सुनना बंद\" बोलिए।"
        AlertDialog.Builder(this)
            .setTitle("क्या-क्या बोल सकते हैं")
            .setMessage(msg)
            .setPositiveButton("ठीक है", null)
            .show()
    }
}
