package com.nobita.ff

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Accessibility Service:
 *  1) Phone lock / home / back / screenshot jaise global actions karta hai.
 *  2) WhatsApp me jab Nobita ne message taiyaar kiya ho, tab "Send" button dabata hai.
 * Ye sirf WhatsApp ki screen dekhta hai (accessibility_config.xml me packageNames).
 */
class NobitaService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: NobitaService? = null

        @Volatile
        var pendingSendUntil: Long = 0L

        fun markPendingSend() {
            pendingSendUntil = System.currentTimeMillis() + 25_000L
        }

        fun globalAction(action: Int): Boolean {
            return instance?.performGlobalAction(action) ?: false
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (System.currentTimeMillis() > pendingSendUntil) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg != "com.whatsapp" && pkg != "com.whatsapp.w4b") return
        val root = rootInActiveWindow ?: return
        val node = findSendButton(root) ?: return
        if (clickNode(node)) {
            pendingSendUntil = 0L
        }
    }

    private fun findSendButton(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val byId = root.findAccessibilityNodeInfosByViewId(root.packageName.toString() + ":id/send")
        if (!byId.isNullOrEmpty()) return byId[0]
        return findByDescription(root, 0)
    }

    private fun findByDescription(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > 25) return null
        val d = node.contentDescription?.toString()?.trim()?.lowercase()
        if (d != null && (d == "send" || d == "भेजें" || d == "भेजे")) return node
        for (i in 0 until node.childCount) {
            val r = findByDescription(node.getChild(i), depth + 1)
            if (r != null) return r
        }
        return null
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        while (n != null) {
            if (n.isClickable) {
                return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            n = n.parent
        }
        return false
    }
}
