package com.nobita.ff

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Nobita ka dimaag: bole gaye text ko samajhkar kaam karta hai.
 * Har raaste par say(...) zaroor bulaya jaata hai taaki assistant jawab de.
 */
class CommandProcessor(private val act: Activity, private val say: (String) -> Unit) {

    private data class Contact(val name: String, val number: String)

    private val prefs = act.getSharedPreferences("nobita", Context.MODE_PRIVATE)

    // ---------- shabd-suchiyan ----------

    private val wakeWords = listOf(
        "hey nobita", "ok nobita", "हे नोबिता", "ओके नोबिता",
        "nobita", "नोबिता", "नोबीता", "नोबिटा", "नोबीटा"
    )

    private val waVariants = listOf(
        "व्हाट्स ऐप", "व्हाट्स एप", "वाट्स ऐप", "वाट्स एप", "वॉट्स ऐप", "whats app",
        "व्हाट्सएप्प", "व्हाट्सऐप", "व्हाट्सएप", "व्हॉट्सऐप", "व्हॉट्सएप", "व्हाट्सअप",
        "वाट्सएप", "वाट्सऐप", "वाट्सअप", "वॉट्सऐप", "वॉट्सएप", "वट्सऐप", "वट्सएप"
    )

    private val numberWords: Map<String, Int> = mapOf(
        "एक" to 1, "ek" to 1, "one" to 1,
        "दो" to 2, "do" to 2, "two" to 2,
        "तीन" to 3, "teen" to 3, "three" to 3,
        "चार" to 4, "char" to 4, "four" to 4,
        "पांच" to 5, "पाँच" to 5, "paanch" to 5, "panch" to 5, "five" to 5,
        "छह" to 6, "छः" to 6, "छे" to 6, "chhe" to 6, "six" to 6,
        "सात" to 7, "saat" to 7, "seven" to 7,
        "आठ" to 8, "aath" to 8, "eight" to 8,
        "नौ" to 9, "nau" to 9, "nine" to 9,
        "दस" to 10, "das" to 10, "ten" to 10,
        "ग्यारह" to 11, "gyarah" to 11, "eleven" to 11,
        "बारह" to 12, "barah" to 12, "twelve" to 12
    )

    private val appAliases: Map<String, String> = mapOf(
        "फ्री फायर मैक्स" to "free fire max", "फ्री फायर" to "free fire", "फ्री फ़ायर" to "free fire",
        "फ्रीफायर" to "free fire", "free fire" to "free fire",
        "यूट्यूब" to "youtube", "यू ट्यूब" to "youtube",
        "फेसबुक" to "facebook", "इंस्टाग्राम" to "instagram", "इंस्टा" to "instagram",
        "क्रोम" to "chrome", "गूगल मैप्स" to "maps", "गूगल मैप" to "maps", "मैप्स" to "maps",
        "गूगल" to "google", "कैमरा" to "camera", "गैलरी" to "gallery", "सेटिंग्स" to "settings",
        "सेटिंग" to "settings", "कैलकुलेटर" to "calculator", "कैलेंडर" to "calendar",
        "घड़ी" to "clock", "प्ले स्टोर" to "play store", "प्लेस्टोर" to "play store",
        "स्नैपचैट" to "snapchat", "टेलीग्राम" to "telegram", "पेटीएम" to "paytm",
        "फोनपे" to "phonepe", "फोन पे" to "phonepe", "जीमेल" to "gmail",
        "स्पॉटिफाई" to "spotify", "नेटफ्लिक्स" to "netflix", "ट्विटर" to "twitter",
        "बीजीएमआई" to "bgmi", "फाइल्स" to "files", "संपर्क" to "contacts", "कॉन्टैक्ट्स" to "contacts",
        "मैसेज" to "messages", "व्हाट्सएप" to "whatsapp"
    )

    private val openVerbsStrong = listOf("open", "kholo", "खोलो", "खोल दो", "खोलिए", "खोलिये", "khol do", "launch", "लॉन्च")
    private val openVerbsWeak = listOf("start", "चालू करो", "शुरू करो", "चलाओ", "chalao", "chalu")

    private val fillWords = setOf(
        "karo", "करो", "kar", "कर", "do", "दो", "ko", "को", "app", "ऐप", "एप", "एप्प", "please", "plz",
        "प्लीज", "na", "न", "zara", "जरा", "ज़रा", "ek", "एक", "mere", "मेरे", "meri", "मेरी", "mera", "मेरा",
        "ji", "जी", "se", "से", "pe", "par", "पर", "पे", "me", "mein", "में", "ki", "की", "ka", "का", "ke", "के"
    )

    // ---------- mukhya function ----------

    fun handle(raw: String) {
        val t = normalize(raw)
        if (t.isEmpty()) {
            say("मैंने कुछ सुना नहीं।")
            return
        }
        try {
            route(t)
        } catch (e: Exception) {
            say("कुछ गड़बड़ हो गई, फिर से कोशिश कीजिए।")
        }
    }

    private fun route(t: String) {
        // 1) WhatsApp message (pehle, taaki message ke andar "lock" jaise shabd se phone lock na ho)
        if (tryWhatsApp(t)) return
        // 2) Unlock (Android allow nahi karta)
        if (has(t, "unlock", "अनलॉक", "अन लॉक", "अनलोक", "अन्लॉक")) {
            say("माफ़ कीजिए, Android की सुरक्षा की वजह से कोई भी ऐप फ़ोन अनलॉक नहीं कर सकता। आप पिन या फ़िंगरप्रिंट से खुद खोल लीजिए।")
            return
        }
        // 3) Lock
        if (hasWord(t, "lock") || has(t, "लॉक", "ताला", "screen off", "स्क्रीन बंद", "स्क्रीन ऑफ", "स्क्रीन आफ")) {
            lockPhone()
            return
        }
        // 4) Call
        if (tryCall(t)) return
        // 5) Alarm / Timer
        if (tryAlarmOrTimer(t)) return
        // 6) Torch
        if (has(t, "torch", "टॉर्च", "टोर्च", "टार्च", "flashlight", "flash light", "फ्लैशलाइट", "फ्लैश लाइट", "बत्ती")) {
            torch(!has(t, "off", "बंद", "band", "बुझा", "ऑफ", "आफ"))
            return
        }
        // 7) Volume
        if (has(t, "volume", "वॉल्यूम", "वोल्यूम", "वाल्यूम", "आवाज")) {
            volume(t)
            return
        }
        // 8) System buttons
        if (trySystemButtons(t)) return
        // 9) Settings panels
        if (trySettingsPanels(t)) return
        // 10) Time / date
        if (has(t, "कितने बजे", "टाइम क्या", "समय क्या", "what time", "time kya", "time batao", "टाइम बताओ", "समय बताओ")) {
            tellTime()
            return
        }
        if (has(t, "तारीख", "date kya", "date batao", "आज क्या दिन", "today date", "डेट क्या", "डेट बताओ")) {
            tellDate()
            return
        }
        // 11) App kholna
        if (tryOpenApp(t)) return
        // 12) Maps
        if (has(t, "navigate", "नेविगेट", "रास्ता", "directions", "नक्शा", "मैप पर", "map par", "map pe")) {
            maps(t)
            return
        }
        // 13) YouTube / gaana
        if (has(t, "youtube", "यूट्यूब", "यू ट्यूब", "play ", "प्ले ", "bajao", "बजाओ", "gana", "गाना", "गाने", "gaane", "song", "सॉन्ग", "सोंग", "music", "म्यूजिक")) {
            music(t)
            return
        }
        // 14) Google search
        if (has(t, "search", "सर्च", "google par", "google pe", "गूगल पर", "खोजो", "ढूंढो", "ढूँढो", "dhundo", "khojo")) {
            webSearch(t)
            return
        }
        // 15) Baaki sab kuch - Claude se poochho
        askClaude(t)
    }

    // ---------- helpers ----------

    private fun has(t: String, vararg words: String): Boolean = words.any { t.contains(it) }

    /** Poora English shabd match karta hai (jaise "lock" to match, par "block" ya "clock" nahi). */
    private fun hasWord(t: String, w: String): Boolean =
        Regex("(^|[^a-z])" + Regex.escape(w) + "([^a-z]|$)").containsMatchIn(t)

    private fun tokens(t: String): List<String> = t.split(" ").filter { it.isNotBlank() }

    private fun normalize(raw: String): String {
        var s = raw.lowercase(Locale.ROOT)
        val sb = StringBuilder()
        for (ch in s) {
            if (ch in '०'..'९') {
                sb.append('0' + (ch - '०'))
            } else {
                sb.append(ch)
            }
        }
        s = sb.toString()
        s = s.replace(Regex("[,.!?।\"']"), " ")
        for (v in waVariants) s = s.replace(v, " whatsapp ")
        s = s.replace(Regex("\\s+"), " ").trim()
        var changed = true
        while (changed) {
            changed = false
            for (w in wakeWords) {
                if (s == w) {
                    s = ""
                    changed = true
                } else if (s.startsWith("$w ")) {
                    s = s.substring(w.length).trim()
                    changed = true
                }
            }
        }
        return s
    }

    private fun openSettingsScreen(action: String) {
        act.startActivity(Intent(action))
    }

    private fun globalNav(action: Int, okMsg: String) {
        if (NobitaService.instance == null) {
            say("पहले Accessibility सेटिंग में Nobita FF चालू कीजिए।")
            openSettingsScreen(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            return
        }
        say(okMsg)
        act.window.decorView.postDelayed({ NobitaService.globalAction(action) }, 900)
    }

    // ---------- lock ----------

    private fun lockPhone() {
        globalNav(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "फ़ोन लॉक कर रहा हूँ।")
    }

    // ---------- system buttons ----------

    private fun trySystemButtons(t: String): Boolean {
        when {
            has(t, "screenshot", "स्क्रीनशॉट", "स्क्रीन शॉट", "screen shot") ->
                globalNav(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "स्क्रीनशॉट ले रहा हूँ।")
            has(t, "go home", "home screen", "होम स्क्रीन", "होम पर", "होम जाओ", "ghar jao") ->
                globalNav(AccessibilityService.GLOBAL_ACTION_HOME, "होम स्क्रीन पर जा रहा हूँ।")
            t == "home" || t == "होम" ->
                globalNav(AccessibilityService.GLOBAL_ACTION_HOME, "होम स्क्रीन पर जा रहा हूँ।")
            has(t, "go back", "पीछे जाओ", "वापस जाओ", "बैक", "peeche", "piche") || t == "back" ->
                globalNav(AccessibilityService.GLOBAL_ACTION_BACK, "पीछे जा रहा हूँ।")
            has(t, "recent", "रीसेंट", "रिसेंट") ->
                globalNav(AccessibilityService.GLOBAL_ACTION_RECENTS, "हाल के ऐप दिखा रहा हूँ।")
            has(t, "notification", "नोटिफिकेशन", "नोटिफ़िकेशन") ->
                globalNav(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "नोटिफिकेशन खोल रहा हूँ।")
            has(t, "quick settings", "क्विक सेटिंग") ->
                globalNav(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS, "क्विक सेटिंग खोल रहा हूँ।")
            else -> return false
        }
        return true
    }

    // ---------- settings panels ----------

    private fun trySettingsPanels(t: String): Boolean {
        val action: String
        val msg: String
        when {
            has(t, "wifi", "wi fi", "वाईफाई", "वाइफाई", "वाई फाई", "वाई-फाई", "इंटरनेट", "internet") -> {
                action = Settings.Panel.ACTION_INTERNET_CONNECTIVITY
                msg = "इंटरनेट की सेटिंग खोल रहा हूँ। Android ऐप को सीधे वाई-फाई चालू या बंद करने नहीं देता, यहाँ से आप कर सकते हैं।"
            }
            has(t, "bluetooth", "ब्लूटूथ", "ब्लूटुथ") -> {
                action = Settings.ACTION_BLUETOOTH_SETTINGS
                msg = "ब्लूटूथ सेटिंग खोल रहा हूँ।"
            }
            has(t, "hotspot", "हॉटस्पॉट", "हॉट स्पॉट") -> {
                action = "android.settings.TETHER_SETTINGS"
                msg = "हॉटस्पॉट सेटिंग खोल रहा हूँ।"
            }
            has(t, "airplane", "flight mode", "एयरप्लेन", "फ्लाइट मोड") -> {
                action = Settings.ACTION_AIRPLANE_MODE_SETTINGS
                msg = "एयरप्लेन मोड की सेटिंग खोल रहा हूँ।"
            }
            has(t, "location", "लोकेशन") -> {
                action = Settings.ACTION_LOCATION_SOURCE_SETTINGS
                msg = "लोकेशन सेटिंग खोल रहा हूँ।"
            }
            has(t, "brightness", "ब्राइटनेस") -> {
                action = Settings.ACTION_DISPLAY_SETTINGS
                msg = "डिस्प्ले सेटिंग खोल रहा हूँ।"
            }
            else -> return false
        }
        say(msg)
        openSettingsScreen(action)
        return true
    }

    // ---------- torch / volume ----------

    private fun torch(on: Boolean) {
        val cm = act.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        if (id == null) {
            say("इस फ़ोन में टॉर्च नहीं मिली।")
            return
        }
        cm.setTorchMode(id, on)
        say(if (on) "टॉर्च चालू कर दी।" else "टॉर्च बंद कर दी।")
    }

    private fun volume(t: String) {
        val am = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val stream = AudioManager.STREAM_MUSIC
        when {
            has(t, "full", "फुल", "max", "मैक्स", "पूरी") -> {
                am.setStreamVolume(stream, am.getStreamMaxVolume(stream), AudioManager.FLAG_SHOW_UI)
                say("वॉल्यूम फुल कर दिया।")
            }
            has(t, "mute", "म्यूट", "zero", "जीरो", "बंद", "band") -> {
                am.setStreamVolume(stream, 0, AudioManager.FLAG_SHOW_UI)
                say("आवाज़ बंद कर दी।")
            }
            has(t, "kam", "कम", "down", "घटा", "ghata", "decrease", "low", "धीमा", "dheema") -> {
                repeat(3) { am.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
                say("वॉल्यूम कम कर दिया।")
            }
            has(t, "badha", "बढ़ा", "बढा", "up", "zyada", "ज्यादा", "ज़्यादा", "increase", "तेज", "tez", "high") -> {
                repeat(3) { am.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
                say("वॉल्यूम बढ़ा दिया।")
            }
            else -> {
                am.adjustStreamVolume(stream, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI)
                say("वॉल्यूम बढ़ाना है या कम करना है?")
            }
        }
    }

    // ---------- time / date ----------

    private fun tellTime() {
        val c = Calendar.getInstance()
        val h24 = c.get(Calendar.HOUR_OF_DAY)
        val min = c.get(Calendar.MINUTE)
        val period = when (h24) {
            in 4..11 -> "सुबह"
            in 12..15 -> "दोपहर"
            in 16..19 -> "शाम"
            else -> "रात"
        }
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        say("अभी $period के $h12 बजकर $min मिनट हुए हैं।")
    }

    private fun tellDate() {
        val f = SimpleDateFormat("d MMMM yyyy, EEEE", Locale("hi", "IN"))
        say("आज " + f.format(Date()) + " है।")
    }

    // ---------- contacts ----------

    private fun loadContacts(): List<Contact> {
        if (act.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return emptyList()
        }
        val list = ArrayList<Contact>()
        val cursor = act.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )
        cursor?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0)
                val p = c.getString(1)
                if (n != null && p != null) list.add(Contact(n, p))
            }
        }
        return list
    }

    private fun findContact(spoken: List<String>): Contact? {
        val contacts = loadContacts()
        if (contacts.isEmpty()) return null
        val full = Translit.skeleton(spoken.joinToString(""))
        val toks = spoken.map { Translit.skeleton(it) }.filter { it.isNotEmpty() }
        var best: Contact? = null
        var bestScore = 0
        for (c in contacts) {
            val cFull = Translit.skeleton(c.name)
            val cToks = c.name.split(" ", "-", "_")
                .filter { it.isNotBlank() }
                .map { Translit.skeleton(it) }
                .filter { it.isNotEmpty() }
            var score = 0
            if (cFull.isNotEmpty() && cFull == full) score += 100
            for (tk in toks) {
                if (cToks.contains(tk)) {
                    score += 10
                } else if (tk.length >= 2 && cToks.any { it.length >= 2 && (it.startsWith(tk) || tk.startsWith(it)) }) {
                    score += 4
                }
            }
            if (score > bestScore) {
                bestScore = score
                best = c
            }
        }
        return best
    }

    private fun contactsPermissionOk(): Boolean {
        if (act.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) return true
        say("कॉन्टैक्ट देखने की अनुमति चाहिए। ऐप की सेटिंग में Contacts की अनुमति दे दीजिए।")
        act.requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 2)
        return false
    }

    // ---------- WhatsApp ----------

    private val nameStop = setOf(
        "mere", "मेरे", "meri", "मेरी", "mera", "मेरा", "dost", "दोस्त", "friend", "ke", "के", "ka", "का",
        "ko", "को", "send", "bhejo", "भेजो", "message", "मैसेज", "मेसेज", "msg", "ji", "जी", "ek", "एक",
        "ye", "ये", "wo", "वो", "usko", "उसको", "unko", "उनको", "se", "से",
        "pe", "par", "पर", "पे", "me", "mein", "में"
    )

    private val msgLeadFill = setOf(
        "par", "pe", "पर", "पे", "me", "mein", "में", "message", "मैसेज", "मेसेज", "msg", "ki", "की", "कि",
        "ye", "ये", "kaho", "कहो", "bolo", "बोलो", "likho", "लिखो", "bhejo", "भेजो", "send", "ke", "के", "liye", "लिए",
        "karo", "करो", "ki", "that"
    )

    private val msgTailVerbs = setOf(
        "bhejo", "भेजो", "bhej", "भेज", "do", "दो", "dena", "देना", "de", "दे", "karo", "करो", "kar", "कर",
        "likho", "लिखो", "send", "bolo", "बोलो", "kaho", "कहो", "please", "plz", "प्लीज", "na", "न",
        "bhijwao", "भिजवाओ", "dijiye", "दीजिए", "kijiye", "कीजिए"
    )

    private val msgSeparators = setOf("message", "मैसेज", "मेसेज", "msg", "bolo", "बोलो", "kaho", "कहो", "likho", "लिखो")

    private fun tryWhatsApp(t: String): Boolean {
        if (!t.contains("whatsapp")) return false
        val toks = tokens(t)
        val wi = toks.indexOf("whatsapp")
        if (wi < 0) return false
        val before = toks.subList(0, wi).toMutableList()
        val after = toks.subList(wi + 1, toks.size).toMutableList()

        val nameToks: MutableList<String>
        val msgToks: MutableList<String>

        if (before.isNotEmpty() && (before.last() == "ko" || before.last() == "को")) {
            // "Rahul ko whatsapp pe hello bhejo"
            before.removeAt(before.size - 1)
            nameToks = before
            msgToks = after
        } else {
            val sep = after.indexOfFirst { it in msgSeparators }
            val koIdx = after.indexOfFirst { it == "ko" || it == "को" }
            if (koIdx > 0 && (sep <= 0 || koIdx < sep)) {
                // "whatsapp pe Rahul ko hello bhejo"
                nameToks = after.subList(0, koIdx).toMutableList()
                msgToks = after.subList(koIdx + 1, after.size).toMutableList()
            } else if (sep > 0) {
                // "whatsapp Rahul message hello"
                nameToks = after.subList(0, sep).toMutableList()
                msgToks = after.subList(sep + 1, after.size).toMutableList()
            } else {
                return false
            }
        }

        val cleanName = nameToks.filter { it !in nameStop }
        while (msgToks.isNotEmpty() && msgToks.first() in msgLeadFill) msgToks.removeAt(0)
        while (msgToks.isNotEmpty() && msgToks.last() in msgTailVerbs) msgToks.removeAt(msgToks.size - 1)
        val message = msgToks.joinToString(" ").trim()

        if (cleanName.isEmpty()) {
            say("किसको मैसेज भेजना है? ऐसे बोलिए: राहुल को व्हाट्सएप पर हेलो भेजो।")
            return true
        }
        if (message.isEmpty()) {
            say("क्या मैसेज भेजना है? ऐसे बोलिए: राहुल को व्हाट्सएप पर हेलो भेजो।")
            return true
        }
        if (!contactsPermissionOk()) return true

        val contact = findContact(cleanName)
        if (contact == null) {
            say("${cleanName.joinToString(" ")} नाम का कॉन्टैक्ट नहीं मिला।")
            return true
        }

        var phone = contact.number.filter { it.isDigit() }
        if (phone.length == 10) phone = "91$phone"
        if (phone.length == 11 && phone.startsWith("0")) phone = "91" + phone.substring(1)

        val uri = Uri.parse("https://api.whatsapp.com/send?phone=$phone&text=" + Uri.encode(message))
        val serviceOn = NobitaService.instance != null
        if (serviceOn) NobitaService.markPendingSend()

        var launched = false
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                act.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg))
                launched = true
                break
            } catch (e: Exception) {
                // agla package try karo
            }
        }
        if (!launched) {
            NobitaService.pendingSendUntil = 0L
            say("WhatsApp नहीं मिला। क्या यह फ़ोन में इंस्टॉल है?")
            return true
        }
        if (serviceOn) {
            say("${contact.name} को मैसेज भेज रहा हूँ।")
        } else {
            say("${contact.name} का चैट खोल दिया है। अपने आप भेजने के लिए Accessibility में Nobita FF चालू कीजिए, अभी सेंड दबा दीजिए।")
        }
        return true
    }

    // ---------- call ----------

    private val callWords = setOf(
        "call", "कॉल", "dial", "डायल", "phone", "फोन", "फ़ोन", "lagao", "लगाओ", "laga", "लगा", "milao", "मिलाओ",
        "number", "नंबर", "नम्बर", "karo", "करो", "kar", "कर", "do", "दो", "ko", "को", "dost", "दोस्त",
        "mere", "मेरे", "ek", "एक", "pe", "par", "पर", "please", "plz", "प्लीज", "ji", "जी", "ke", "के"
    )

    private fun tryCall(t: String): Boolean {
        if (!has(t, "call", "कॉल", "फोन करो", "फ़ोन करो", "phone karo", "फोन लगाओ", "phone lagao", "dial", "डायल")) return false
        val rest = tokens(t).filter { it !in callWords }
        val digits = rest.joinToString("").filter { it.isDigit() }
        if (digits.length >= 6) {
            say("$digits पर कॉल कर रहा हूँ।")
            placeCall(digits)
            return true
        }
        if (rest.isEmpty()) {
            say("किसको कॉल करना है?")
            return true
        }
        if (!contactsPermissionOk()) return true
        val contact = findContact(rest)
        if (contact == null) {
            say("${rest.joinToString(" ")} नाम का कॉन्टैक्ट नहीं मिला।")
            return true
        }
        say("${contact.name} को कॉल कर रहा हूँ।")
        placeCall(contact.number)
        return true
    }

    private fun placeCall(number: String) {
        val uri = Uri.fromParts("tel", number, null)
        if (act.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            act.startActivity(Intent(Intent.ACTION_CALL, uri))
        } else {
            act.startActivity(Intent(Intent.ACTION_DIAL, uri))
        }
    }

    // ---------- alarm / timer ----------

    private fun findNumber(t: String): Int? {
        val m = Regex("\\d+").find(t)
        if (m != null) return m.value.toInt()
        for (tok in tokens(t)) {
            val v = numberWords[tok]
            if (v != null) return v
        }
        return null
    }

    private fun tryAlarmOrTimer(t: String): Boolean {
        if (has(t, "timer", "टाइमर")) {
            val n = findNumber(t)
            if (n == null) {
                say("कितने समय का टाइमर लगाना है?")
                return true
            }
            val seconds = when {
                has(t, "second", "सेकंड", "सेकण्ड", "sec") -> n
                has(t, "hour", "घंटा", "घंटे", "ghante", "ghanta") -> n * 3600
                else -> n * 60
            }
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Nobita")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            act.startActivity(i)
            say("टाइमर लगा दिया।")
            return true
        }
        if (has(t, "alarm", "अलार्म", "अलारम")) {
            var hour: Int
            var minute = 0
            val m = Regex("(\\d{1,2})(?:[: ](\\d{2}))?\\b").find(t)
            if (m != null) {
                hour = m.groupValues[1].toInt()
                if (m.groupValues[2].isNotEmpty()) minute = m.groupValues[2].toInt()
            } else {
                val w = tokens(t).firstNotNullOfOrNull { numberWords[it] }
                if (w == null) {
                    say("किस समय का अलार्म लगाना है? जैसे: सुबह 7 बजे का अलार्म लगाओ।")
                    return true
                }
                hour = w
            }
            if (hour > 23 || minute > 59) {
                say("समय सही नहीं लगा, फिर से बोलिए।")
                return true
            }
            val pm = hasWord(t, "pm") || Regex("\\dpm").containsMatchIn(t) ||
                has(t, "शाम", "रात", "दोपहर", "dopahar", "sham", "raat", "evening", "night", "afternoon")
            val am = hasWord(t, "am") || Regex("\\dam").containsMatchIn(t) ||
                has(t, "सुबह", "subah", "morning")
            if (pm && hour in 1..11) hour += 12
            if (am && hour == 12) hour = 0
            val i = Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Nobita")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            act.startActivity(i)
            say("अलार्म लगा दिया, " + String.format(Locale.US, "%02d:%02d", hour, minute) + " बजे के लिए।")
            return true
        }
        return false
    }

    // ---------- app kholna ----------

    private fun tryOpenApp(t: String): Boolean {
        val strong = openVerbsStrong.firstOrNull { t.contains(it) }
        val weak = if (strong == null) openVerbsWeak.firstOrNull { t.contains(it) } else null
        val verb = strong ?: weak ?: return false

        var name = t
        for (v in openVerbsStrong + openVerbsWeak) name = name.replace(v, " ")
        val nameToks = tokens(name).filter { it !in fillWords }
        if (nameToks.isEmpty()) {
            if (strong != null) say("कौन सा ऐप खोलना है?")
            return strong != null
        }
        val query = nameToks.joinToString(" ")
        val pkg = findAppPackage(query)
        if (pkg == null) {
            if (verb == strong) {
                say("$query नाम का ऐप नहीं मिला।")
                return true
            }
            return false
        }
        val launch = act.packageManager.getLaunchIntentForPackage(pkg)
        if (launch == null) {
            say("$query खोल नहीं पाया।")
            return true
        }
        say("$query खोल रहा हूँ।")
        act.startActivity(launch)
        return true
    }

    private fun findAppPackage(spoken: String): String? {
        var q = spoken.lowercase(Locale.ROOT)
        for ((k, v) in appAliases.entries.sortedByDescending { it.key.length }) q = q.replace(k, v)
        q = q.trim()
        if (q.isEmpty()) return null
        val qSkel = Translit.skeleton(q)

        val pm = act.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        var bestPkg: String? = null
        var bestScore = 0
        for (ri in apps) {
            val label = ri.loadLabel(pm).toString().lowercase(Locale.ROOT)
            val lSkel = Translit.skeleton(label)
            var score = 0
            if (label == q) score = 100
            else if (label.startsWith(q) || q.startsWith(label) && label.length >= 3) score = 60
            else if (label.contains(q) || q.contains(label) && label.length >= 3) score = 40
            else if (qSkel.isNotEmpty() && lSkel == qSkel) score = 45
            else if (qSkel.length >= 3 && lSkel.length >= 3 && (lSkel.contains(qSkel) || qSkel.contains(lSkel))) score = 20
            // Free Fire MAX ko normal Free Fire par tarjeeh na mile jab MAX bola gaya ho
            if (score > 0 && q.contains("max") && label.contains("max")) score += 5
            if (score > bestScore) {
                bestScore = score
                bestPkg = ri.activityInfo.packageName
            }
        }
        return bestPkg
    }

    // ---------- maps / music / search ----------

    private val mapWords = setOf(
        "navigate", "नेविगेट", "रास्ता", "directions", "दिखाओ", "dikhao", "batao", "बताओ", "map", "मैप", "नक्शा",
        "par", "pe", "पर", "पे", "ka", "का", "ke", "के", "liye", "लिए", "karo", "करो", "mujhe", "मुझे", "tak", "तक",
        "jane", "जाने", "jana", "जाना", "hai", "है", "chahiye", "चाहिए", "ko", "को"
    )

    private fun maps(t: String) {
        val q = tokens(t).filter { it !in mapWords }.joinToString(" ")
        if (q.isEmpty()) {
            say("कहाँ जाना है?")
            return
        }
        say("$q का रास्ता खोल रहा हूँ।")
        act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(q))))
    }

    private val musicWords = setOf(
        "youtube", "यूट्यूब", "यू", "ट्यूब", "play", "प्ले", "bajao", "बजाओ", "chalao", "चलाओ", "gana", "गाना", "gaana",
        "गाने", "gaane", "song", "सॉन्ग", "सोंग", "music", "म्यूजिक", "par", "pe", "पर", "पे", "ka", "का", "ke", "के",
        "ki", "की", "karo", "करो", "kholo", "खोलो", "search", "सर्च", "mere", "मेरे", "ek", "एक", "ko", "को", "se", "से",
        "लगाओ", "lagao", "सुनाओ", "sunao"
    )

    private fun music(t: String) {
        val q = tokens(t).filter { it !in musicWords }.joinToString(" ")
        if (q.isEmpty()) {
            say("क्या बजाना है? जैसे: यूट्यूब पर अरिजीत के गाने बजाओ।")
            return
        }
        say("यूट्यूब पर $q ढूंढ रहा हूँ।")
        try {
            act.startActivity(
                Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
            )
        } catch (e: Exception) {
            act.startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
                )
            )
        }
    }

    private val searchWords = setOf(
        "search", "सर्च", "google", "गूगल", "par", "pe", "पर", "पे", "karo", "करो", "khojo", "खोजो", "dhundo",
        "ढूंढो", "ढूँढो", "kar", "कर", "do", "दो", "ke", "के", "baare", "बारे", "me", "mein", "में", "ki", "की", "ka", "का"
    )

    private fun webSearch(t: String) {
        val q = tokens(t).filter { it !in searchWords }.joinToString(" ")
        if (q.isEmpty()) {
            say("क्या सर्च करना है?")
            return
        }
        say("$q सर्च कर रहा हूँ।")
        act.startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
    }

    // ---------- Claude se jawab (optional) ----------

    private fun askClaude(q: String) {
        val key = prefs.getString("api_key", "") ?: ""
        if (key.isBlank()) {
            say("यह कमांड मुझे समझ नहीं आई। हर सवाल का जवाब पाने के लिए ऐप में Claude API Key डाल दीजिए।")
            return
        }
        Thread {
            try {
                val body = JSONObject()
                    .put("model", "claude-haiku-5-5")
                    .put("max_tokens", 300)
                    .put(
                        "system",
                        "You are Nobita, a friendly voice assistant on an Android phone. " +
                            "Reply in short, simple Hindi (Devanagari script), at most 3 sentences, no markdown, no emojis."
                    )
                    .put(
                        "messages",
                        JSONArray().put(JSONObject().put("role", "user").put("content", q))
                    )
                val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("x-api-key", key)
                conn.setRequestProperty("anthropic-version", "2023-06-01")
                conn.setRequestProperty("content-type", "application/json")
                conn.doOutput = true
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                if (code in 200..299) {
                    val ans = JSONObject(text).getJSONArray("content").getJSONObject(0).getString("text")
                    act.runOnUiThread { say(ans) }
                } else {
                    act.runOnUiThread { say("Claude से जवाब नहीं मिला। API Key जाँच लीजिए। कोड $code।") }
                }
            } catch (e: Exception) {
                act.runOnUiThread { say("इंटरनेट में कुछ दिक्कत है।") }
            }
        }.start()
    }
}
