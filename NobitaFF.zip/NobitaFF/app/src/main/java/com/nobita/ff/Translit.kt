package com.nobita.ff

/**
 * Hindi (Devanagari) aur English naam ko ek "skeleton" me badalta hai taaki
 * "राहुल" aur "Rahul" ek jaise match ho sakein.
 */
object Translit {
    private val map: Map<Char, String> = mapOf(
        'क' to "k", 'ख' to "k", 'ग' to "g", 'घ' to "g", 'ङ' to "n",
        'च' to "c", 'छ' to "c", 'ज' to "j", 'झ' to "j", 'ञ' to "n",
        'ट' to "t", 'ठ' to "t", 'ड' to "d", 'ढ' to "d", 'ण' to "n",
        'त' to "t", 'थ' to "t", 'द' to "d", 'ध' to "d", 'न' to "n",
        'प' to "p", 'फ' to "f", 'ब' to "b", 'भ' to "b", 'म' to "m",
        'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "s",
        'ष' to "s", 'स' to "s", 'ळ' to "l", 'ं' to "n", 'ँ' to "n",
        'क़' to "k", 'ख़' to "k", 'ग़' to "g", 'ज़' to "j",
        'ड़' to "r", 'ढ़' to "r", 'फ़' to "f", 'य़' to "y"
    )
    private val dupRegex = Regex("(.)\\1+")
    private val vowelRegex = Regex("[aeiou]")

    fun skeleton(input: String): String {
        val sb = StringBuilder()
        for (ch in input.lowercase()) {
            val m = map[ch]
            if (m != null) {
                sb.append(m)
            } else if (ch in 'a'..'z') {
                sb.append(ch)
            }
        }
        var t = sb.toString()
        t = t.replace("ph", "f").replace("sh", "s").replace("ch", "c")
        t = t.replace("h", "").replace("w", "v").replace("z", "j").replace("q", "k").replace("x", "ks")
        t = vowelRegex.replace(t, "")
        t = dupRegex.replace(t, "\$1")
        return t
    }
}
